package com.macys;

import java.io.Serializable;

public interface IKafkaKey extends Serializable {
    public String key();
}

package com.macys;

import com.macys.CassandraUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.beam.sdk.transforms.DoFn;

import java.io.Serializable;
import java.util.List;

@Slf4j
public class WriteToCassandra extends DoFn<List<Object>, String> implements Serializable {

    CassandraUtil cassandraUtil;

    public WriteToCassandra(CassandraUtil cassandraUtil){
        this.cassandraUtil = cassandraUtil;
    }

    @ProcessElement
    public void processElement(@Element List<Object> in, OutputReceiver<String> out) throws Exception {
        //log.info("Writing To Cassandra Process called");

   
            cassandraUtil.writeToCassandra(in);
            out.output("Object saved");
       
    }
}

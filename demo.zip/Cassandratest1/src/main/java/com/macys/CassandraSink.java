package com.macys;

import com.macys.PipelineTransformer;
import com.macys.WriteToCassandra;
import com.macys.CassandraUtil;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TupleTag;

public class CassandraSink implements ISink {

    CassandraUtil cassandraUtil;

    private TupleTag sinkTag = PipelineTransformer.TAG_CASSANDRA_SINK;

    public TupleTag getSinkTag(){
        return sinkTag;
    }

    public CassandraSink(CassandraUtil cassandraUtil){
        this.cassandraUtil = cassandraUtil;
    }

    @Override
    public void saveToSink(PCollection list) {
        list.apply("Write to Cassandra", ParDo.of(new WriteToCassandra(cassandraUtil)));
    }
}

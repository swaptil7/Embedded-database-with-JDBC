package com.macys;

import org.apache.beam.sdk.io.kafka.KafkaRecord;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;

import java.io.Serializable;

public interface PipelineTransformer extends Serializable {

    String CASSANDRA_SINK = "cassandra";
    String KAFKA_SINK = "kafka";
    String KAFKA_SOURCE = "kafka_source";
    String DLQ_SINK = "dlq";
    String API_SINK = "api";

    TupleTag<String> TAG_CASSANDRA_SINK = new TupleTag<String>(CASSANDRA_SINK) {};
    TupleTag<String> TAG_API_SINK = new TupleTag<String>(API_SINK) {};

    PCollectionTuple transformInput(PCollection<KafkaRecord<String, String>> input);
}

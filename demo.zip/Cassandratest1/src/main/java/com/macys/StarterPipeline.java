/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.macys;

//import com.datastax.driver.mapping.annotations.Column;
//import com.datastax.driver.mapping.annotations.Table;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.apache.beam.runners.direct.DirectRunner;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
import org.apache.beam.sdk.io.TextIO;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.FlatMapElements;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.values.PCollection;

import com.macys.CassandraSink;
import com.macys.CassandraUtil;

import lombok.Data;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A starter example for writing Google Cloud Dataflow programs.
 *
 * <p>
 * The example takes two strings, converts them to their upper-case
 * representation and logs them.
 *
 * <p>
 * To run this starter example locally using DirectPipelineRunner, just execute
 * it without any additional parameters from your favorite development
 * environment.
 *
 * <p>
 * To run this starter example using managed resource in Google Cloud Platform,
 * you should specify the following command-line options:
 * --project=<YOUR_PROJECT_ID>
 * --stagingLocation=<STAGING_LOCATION_IN_CLOUD_STORAGE>
 * --runner=BlockingDataflowPipelineRunner
 */
public class StarterPipeline {
	private static final Logger log = LoggerFactory.getLogger(StarterPipeline.class);
	

	@Data
	@DefaultCoder(AvroCoder.class)
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@JsonPropertyOrder({ "primaryproductid","productid", "relatedproductid" })
	@Table(name="product",keyspace="tutorialspoint")
	static class Product {

		@JsonProperty("primaryproductid")
		@Column(name = "primaryproductid")
		private Integer primaryproductid;


		@JsonProperty("relatedproductid")
		@Column(name = "relatedproductid")
		private Integer relatedproductid;


		@JsonProperty("productid")
		@Column(name = "productid")
		private Integer productid;

		/// Get Set Values
		@JsonProperty("primaryproductid")
		@Column(name = "primaryproductid")
		public Integer getPrimaryproductid() {
			return primaryproductid;
		}

		@JsonProperty("primaryproductid")
		@Column(name = "primaryproductid")
		public void setPrimaryproductid(Integer primaryproductid) {
			this.primaryproductid = primaryproductid;
		}

		@JsonProperty("relatedproductid")
		@Column(name = "relatedproductid")
		public Integer getRelatedproductid() {
			return relatedproductid;
		}

		@JsonProperty("relatedproductid")
		@Column(name = "relatedproductid")
		public void setRelatedproductid(Integer relatedproductid) {
			this.relatedproductid = relatedproductid;
		}


		@JsonProperty("productid")
		@Column(name = "productid")
		public Integer getProductid() {
			return productid;
		}

		@JsonProperty("productid")
		@Column(name = "productid")
		public void setProductid(Integer productid) {
			this.productid = productid;
		}
		
		public Product()
		{
			
		}
		
		public Product(Product p) {
            this.primaryproductid = p.getPrimaryproductid();
            this.relatedproductid = p.getRelatedproductid();
            this.productid = p.getProductid();	
            
        }

    
        @Data
        public class Product2Body implements Serializable {
            @Expose
            @SerializedName("primaryproductid")
            private Integer primaryproductid;
            @Expose
            @SerializedName("relatedproductid")
            private Integer relatedproductid;
            @Expose
            @SerializedName("productid")
            private Integer productid;
            
    
            @Override
            public String toString() {
                com.google.gson.Gson gson = new GsonBuilder().serializeNulls().excludeFieldsWithoutExposeAnnotation().create();
                return gson.toJson(this);
            }
        }
    
        @Override
        public String toString() {
            return new Gson().toJson(this);
        }


		//// End Get Set Values
	}

	public static interface MyOptions extends PipelineOptions {
		String getInputFile();
		String getHost();
		int getPort();
		String getKeyspace();
		String getUsername();
		String getPassword();

		void setInputFile(String value);
		///*
		void setHost(String value);
		void setPort(int value);
		void setKeyspace(String value);
		void setUsername(String value);
		void setPassword(String value); /// */

		/* void setHost();
		void setPort();
		void setKeyspace();
		void setUsername();
		void setPassword();

		*/
	}

	public static void main(String[] args) {

		Pipeline p = parseAndWriteProduct(args);

		p.run().waitUntilFinish();
		

	}

	private static Pipeline parseAndWriteProduct(String[] args) {
		PipelineOptionsFactory.register(MyOptions.class);
		MyOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(MyOptions.class);
		Pipeline p = Pipeline.create(options);

		CassandraUtil util = new CassandraUtil();
		util.setConfig(options.getHost(), options.getPort(),options.getUsername(),options.getPassword());
		CassandraSink sink = new CassandraSink(util);
		// Read Product from a Product file
		sink.saveToSink(p.apply("Read JSON", TextIO.read().from(options.getInputFile()))
				// Parse the Product JSON
				.apply("ParseProduct", ParDo.of(new DoFn<String, List<Product>>() {
					@ProcessElement
					public void processElement(ProcessContext c)
							throws JsonParseException, JsonMappingException, IOException {
						Product p = parseeJson(c.element());
						log.debug("hello",this);
						List<Product> l = new ArrayList<Product>(); 
				        l.add(p); 
						c.output(l);
					}
				})));

		
		
		// [END spanner_dataflow_write]
		return p;
	}

	private static Product parseeJson(String reader) throws JsonParseException, JsonMappingException, IOException {
		// FileReader fileReader = new FileReader(reader);
		ObjectMapper objectMapper = new ObjectMapper();
		Product reader2 = objectMapper.readValue(reader, Product.class);
		return reader2;

	}

}

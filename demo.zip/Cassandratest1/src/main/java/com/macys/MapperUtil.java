package com.macys;

import com.fasterxml.jackson.databind.ObjectMapper;
//import com.macys.IKafkaKey;
import com.macys.Column;
import com.macys.WindowingKey;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class MapperUtil implements Serializable {
    ObjectMapper mapper;

    public void initializeMappers(Map<Field, String> fieldsToColumns, List<Field> keys, Map<Field, Method> getters, Map<Field, Method> setters, Object object){
        List<Field> fields = Arrays.asList(object.getClass().getDeclaredFields());

        List<Method> methods = Arrays.asList(object.getClass().getMethods());
        List<Method> getMethods = methods.stream().filter( method -> {
            return method.getName().substring(0,3).equalsIgnoreCase("get");
        }).collect(Collectors.toList());

        List<Method> isMethods = methods.stream().filter( method -> {
            return method.getName().substring(0,2).equalsIgnoreCase("is");
        }).collect(Collectors.toList());

        List<Method> setMethods = methods.stream().filter( method -> {
            return method.getName().substring(0,3).equalsIgnoreCase("set");
        }).collect(Collectors.toList());


        fields.stream().forEach( field -> {
            if(field.getAnnotation(Column.class) != null) {
                String columnName = field.getAnnotation(Column.class).name();
                WindowingKey windowingKey = field.getAnnotation(WindowingKey.class);
                if (!(columnName == null || columnName.equals("")))
                    fieldsToColumns.put(field, field.getAnnotation(Column.class).name().toUpperCase());
                else if(columnName.equals(""))
                    fieldsToColumns.put(field, field.getName().toUpperCase());
                List<Method> getter = getMethods.stream().filter( method -> {
                    return method.getName().substring(3).equalsIgnoreCase(field.getName());
                }).collect(Collectors.toList());
                List<Method> setter = setMethods.stream().filter( method -> {
                    return method.getName().substring(3).equalsIgnoreCase(field.getName());
                }).collect(Collectors.toList());
                List<Method> is = isMethods.stream().filter( method -> {
                    return method.getName().substring(2).equalsIgnoreCase(field.getName());
                }).collect(Collectors.toList());

                if(windowingKey != null){
                    keys.add(field);
                }

                getters.put(field, getter.size() == 1 ? getter.get(0) : is.size() == 1 ? is.get(0) : null );

                setters.put(field, setter.size() == 1 ? setter.get(0) : null );
            }
        });

    }

    public Long hashcode(Object object) throws Exception{

        Map<Field, String> fieldsToColumns = new HashMap<>();
        Map<Field, Method> getters = new HashMap<>();
        Map<Field, Method> setters = new HashMap<>();
        List<Field> keys = new LinkedList<>();

        initializeMappers(fieldsToColumns, keys, getters, setters, object);

        Long hash = 0L;
        for(Field key: keys){
            hash += Objects.hash(getters.get(key).invoke(object));
        }

        return hash;
    }

//    public Long hashcode(IKafkaKey iKafkaKey) throws Exception{
//
//        Long hash = 0L;
//
//        hash += Objects.hash(iKafkaKey.key());
//
//        return hash;
//    }
}

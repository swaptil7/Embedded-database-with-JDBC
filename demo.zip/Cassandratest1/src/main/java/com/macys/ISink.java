package com.macys;

import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TupleTag;

public interface ISink<K> {

    void saveToSink(PCollection<K> list);
    TupleTag getSinkTag();

}

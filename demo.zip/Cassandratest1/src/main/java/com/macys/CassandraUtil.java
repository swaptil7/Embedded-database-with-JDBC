package com.macys;


import com.datastax.driver.core.*;
import com.datastax.driver.core.querybuilder.Batch;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
import java.lang.NullPointerException;
import com.macys.Table;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.beam.repackaged.beam_sdks_java_core.org.apache.commons.lang3.ArrayUtils;


import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Data
@NoArgsConstructor
public class CassandraUtil implements Serializable {

    private Cluster cluster;
    private Session session;

    private String cassandraHost;
    private Integer cassandraPort;
    private String username;
    private String password;
    private MapperUtil mapperUtil;
    
    public void setConfig(String host, int port,String username, String password)
    {
    	this.cassandraHost = host;
    	this.cassandraPort = port;
    	this.username = username;
    	this.password = password;
    }

    public Object getObject(Object input) throws InvocationTargetException {

        if(session == null)
            initializeSession();

        Object object = null;

        Map<Field, String> columnsToField = new HashMap<>();
        Map<Field, Method> getters = new HashMap<>();
        Map<Field, Method> setters = new HashMap<>();
        List<Field> keys = new LinkedList<>();

        mapperUtil.initializeMappers(columnsToField, keys, getters, setters, input);

        List<Field> mappedFields = new ArrayList<>(columnsToField.keySet());

        String table = input.getClass().getAnnotation(Table.class).name()[0];
        String keyspace = input.getClass().getAnnotation(Table.class).keyspace();

        try {
            Select select = QueryBuilder.select().from(keyspace, table);
            Select.Where where = null;
            for(Field mappedField: mappedFields){
                if( where == null && getters.get(mappedField).invoke(input) != null)
                    where = select.where(QueryBuilder.eq( columnsToField.get(mappedField), getters.get(mappedField).invoke(input)));
                else if(getters.get(mappedField).invoke(input) != null)
                    where = where.and(QueryBuilder.eq( columnsToField.get(mappedField), getters.get(mappedField).invoke(input)));
            }
            if(where == null)
                select = select.limit(1).allowFiltering();
            else
                select = where.limit(1).allowFiltering();

            ResultSet resultSet = session.execute(select);

            Row row = resultSet.one();

            if (row != null) {
                object = input.getClass().getConstructor().newInstance();
                for(Field mappedField: mappedFields){
                    setters.get(mappedField).invoke(object, row.get(columnsToField.get(mappedField), mappedField.getType()));
                }
            } else{
                return null;
            }

            //log.info("*** OBJECT FROM CASSANDRA: " + object.toString());

        } catch (Exception e){
            //log.error("Failed to retrieve item with error: {}", e);
        }
        return object;
    }

    public void writeToCassandra(List<Object> input) throws Exception{

        if(session == null)
            initializeSession();

        Batch batch;
      
            batch = QueryBuilder.batch();
                for(Object object: input) {
                    String[] primary = object.getClass().getAnnotation(Table.class).name();
                    String[] conditional = object.getClass().getAnnotation(Table.class).conditional();
                    String[] combined = ArrayUtils.addAll(primary, conditional);
                    String keyspace = object.getClass().getAnnotation(Table.class).keyspace();
                    for (String table : combined) {
                        batch.add(insertIntoTable(keyspace, table, object));
                    }
                }
            
            session.execute(batch);

            //log.info("*** BATCH WRITE TO CASSANDRA: ");
        } 
    
    public void initializeMappers(Map<Field, String> fieldsToColumns, List<Field> keys, Map<Field, Method> getters, Map<Field, Method> setters, Object object){
        List<Field> fields = Arrays.asList(object.getClass().getDeclaredFields());

        List<Method> methods = Arrays.asList(object.getClass().getMethods());
        List<Method> getMethods = methods.stream().filter( method -> {
            return method.getName().substring(0,3).equalsIgnoreCase("get");
        }).collect(Collectors.toList());

        List<Method> isMethods = methods.stream().filter( method -> {
            return method.getName().substring(0,2).equalsIgnoreCase("is");
        }).collect(Collectors.toList());

        List<Method> setMethods = methods.stream().filter( method -> {
            return method.getName().substring(0,3).equalsIgnoreCase("set");
        }).collect(Collectors.toList());


        fields.stream().forEach( field -> {
            if(field.getAnnotation(Column.class) != null) {
                String columnName = field.getAnnotation(Column.class).name();
                WindowingKey windowingKey = field.getAnnotation(WindowingKey.class);
                if (!(columnName == null || columnName.equals("")))
                    fieldsToColumns.put(field, field.getAnnotation(Column.class).name().toUpperCase());
                else if(columnName.equals(""))
                    fieldsToColumns.put(field, field.getName().toUpperCase());
                List<Method> getter = getMethods.stream().filter( method -> {
                    return method.getName().substring(3).equalsIgnoreCase(field.getName());
                }).collect(Collectors.toList());
                List<Method> setter = setMethods.stream().filter( method -> {
                    return method.getName().substring(3).equalsIgnoreCase(field.getName());
                }).collect(Collectors.toList());
                List<Method> is = isMethods.stream().filter( method -> {
                    return method.getName().substring(2).equalsIgnoreCase(field.getName());
                }).collect(Collectors.toList());

                if(windowingKey != null){
                    keys.add(field);
                }

                getters.put(field, getter.size() == 1 ? getter.get(0) : is.size() == 1 ? is.get(0) : null );

                setters.put(field, setter.size() == 1 ? setter.get(0) : null );
            }
        });

    }

    private RegularStatement insertIntoTable(String keyspace, String tableName , Object object) throws Exception {
        if(session == null)
            initializeSession();

        Map<Field, String> fieldsToColumns = new HashMap<>();
        Map<Field, Method> getters = new HashMap<>();
        Map<Field, Method> setters = new HashMap<>();
        List<Field> keys = new LinkedList<>();


        this.initializeMappers(fieldsToColumns, keys, getters, setters, object);

        List<Field> mappedFields = new ArrayList<>(fieldsToColumns.keySet());

        Map<String, Object> columnsToValues = new HashMap<>();

        for (Field field : mappedFields) {
            columnsToValues.put(fieldsToColumns.get(field), getters.get(field).invoke(object));
        }

        String[] columns = (new ArrayList<>(columnsToValues.keySet())).stream().toArray(String[]::new);
        Object[] values = (new ArrayList<>(columnsToValues.values())).stream().toArray();
        
        System.out.println(keyspace);
        
        for(String s:columns)
        {
        	System.out.println(s);
        }

        return QueryBuilder.insertInto(keyspace, tableName).values(columns, values);
        
      
    }
    public void initializeSession(){
        cluster = Cluster.builder().addContactPoint(cassandraHost).withPort(cassandraPort).withCredentials(username, password).build();
        session = cluster.connect();
    }

}
